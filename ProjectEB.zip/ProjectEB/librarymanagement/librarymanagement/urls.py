
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.main),
    path('home',views.home),
    path('login',views.login),
    path('Profile',views.Profile),
    path('services',views.services),
    path('LOGIN',views.LOGIN),
    path('Logout',views.Logout),
    path('logintask',views.logintask),
    path('Studprofile',views.Studprofile),
    path('addbooks',views.addbooks),
    path('viewbooks',views.viewbooks),
    path('deletebooks',views.deletebooks),
    path('rahulbooks',views.rahulbooks),
    path('rohanbooks',views.rohanbooks),
    path('amanbooks',views.amanbooks),
    path('deleteissuedbooks',views.deleteissuedbooks),
    path('issuebookpage',views.issuebookpage),
    path('stud/',include('student.urls'))
]
