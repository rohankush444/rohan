from django.shortcuts import render
from django.shortcuts import redirect
import mysql.connector as mysql
import datetime
def main(req):
    return render(req,'main.html')
def home(req):
    return render(req,'adminhome.html')
def login(req):
    return render(req,'adminlogin.html')
def services(req):
    return render(req,'services.html')    
def LOGIN(req):
    return redirect("/login")
def Logout(req):
    return redirect("/")    
def Profile(req):
    Name="Rohan"
    Age=24
    Username="Rohan@gmail.com"
    MobileNo=9044851089
    Password="R122"
    return render(req,'adminprofile.html',{"Name":Name,"Age":Age,"Username":Username,"MobileNo":MobileNo,"Password":Password}) 
def logintask(req):
    Email=req.GET.get("Email")
    Pass=req.GET.get("Pass")

    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")

    mycr=conn.cursor()

    mycr.execute("select * from admin")
    while True:
        row=mycr.fetchone()
        if row is None:
            break
        elif row[0]==Email and row[1]==Pass:
            return redirect("/home")   
    return redirect("/login")    

def Studprofile(req):
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")

    mycr=conn.cursor()

    mycr.execute("select name,email,age,mob from student")
    while True:
        row=mycr.fetchall()
        if row is None:
            break
        else:
            return render(req,'studrecord.html',{'row':row})

def addbooks(req):
    Name=req.GET.get("Name")
    Link=req.GET.get("pdf")
    Author=req.GET.get("Author")
    date=req.GET.get("date")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
    que="insert into books values('{0}','{1}','{2}','{3}')".format(Name,Link,Author,date)
    mycr.execute(que)
    conn.commit()
    conn.close()
    return render(req,'addbooks.html')

def viewbooks(req):
	conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
	mycr=conn.cursor()
	mycr.execute("select * from books") 
	while True:
		books=mycr.fetchall()
		if books is None:
			break
		else:
			return render(req,'viewbooks.html',{'books':books})
    
def deletebooks(req):
    Name=req.GET.get("Name")
    Author=req.GET.get("Author")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
   #mycr.execute("delete from books where Name ='{0}' ) Author ='{1}' ".format(Name,Author))
    mycr.execute("delete from books where Name ='{0}'".format(Name) )
    mycr.execute("delete from books where Author ='{0}'".format(Author) )

    conn.commit()
    conn.close()
    return render(req,'deletebooks.html')

def rahulbooks(req):
    Stud_Name=req.GET.get("Stud_Name")
    Name=req.GET.get("Name")
    Link=req.GET.get("pdf")
    Author=req.GET.get("Author")
    date=req.GET.get("date")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
    que="insert into rahulbooks values('{0}','{1}','{2}','{3}','{4}')".format(Stud_Name,Name,Link,Author,date)
    mycr.execute(que)
    conn.commit()
    conn.close()
    return render(req,'studentissuedrecord.html')  

def rohanbooks(req):
    Stud_Name=req.GET.get("Stud_Name")
    Name=req.GET.get("Name")
    Link=req.GET.get("pdf")
    Author=req.GET.get("Author")
    date=req.GET.get("date")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
    que="insert into rohanbooks values('{0}','{1}','{2}','{3}','{4}')".format(Stud_Name,Name,Link,Author,date)
    mycr.execute(que)
    conn.commit()
    conn.close()
    return render(req,'rohanbooks.html')  
	
def amanbooks(req):
    Stud_Name=req.GET.get("Stud_Name")
    Name=req.GET.get("Name")
    Link=req.GET.get("pdf")
    Author=req.GET.get("Author")
    date=req.GET.get("date")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
    que="insert into amanbooks values('{0}','{1}','{2}','{3}','{4}')".format(Stud_Name,Name,Link,Author,date)
    mycr.execute(que)
    conn.commit()
    conn.close()
    return render(req,'amanbooks.html')     

def deleteissuedbooks(req):
    Name=req.GET.get("Name")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
   #mycr.execute("delete from books where Name ='{0}' ) Author ='{1}' ".format(Name,Author))
    mycr.execute("delete from rahulbooks where Name ='{0}'".format(Name) )
    conn.commit()
    conn.close()
    return render(req,'deletebooks.html')

def deleteissuedbooksrohan(req):
    Name=req.GET.get("Name")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
   #mycr.execute("delete from books where Name ='{0}' ) Author ='{1}' ".format(Name,Author))
    mycr.execute("delete from rohanbooks where Name ='{0}'".format(Name) )
    conn.commit()
    conn.close()
    return render(req,'deletebooks.html')

def deleteissuedbooksaman(req):
    Name=req.GET.get("Name")
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()
   #mycr.execute("delete from books where Name ='{0}' ) Author ='{1}' ".format(Name,Author))
    mycr.execute("delete from amanbooks where Name ='{0}'".format(Name) )
    conn.commit()
    conn.close()
    return render(req,'deletebooks.html')


def issuebookpage(req):
    return render(req,'issuebookpage.html') 
                     
    