from django.urls import path
from . import views

urlpatterns = [
    path('home',views.home),
    path('studlogin',views.studlogin),
    path('studregister',views.studregister),  
    path('studinsert',views.studinsert),
    path('studlogintask',views.studlogintask),
    path('viewstudbooks',views.viewstudbooks),
    path('issuebooksrahul',views.issuebooksrahul),
    path('issuebooksrohan',views.issuebooksrohan),
    path('issuebooksaman',views.issuebooksaman),
    path('requestbook',views.requestbook),
    path('aboutus',views.aboutus),

]
