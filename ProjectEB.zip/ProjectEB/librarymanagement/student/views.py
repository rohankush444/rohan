from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
import mysql.connector as mysql

def home(req):
    return render(req,'studenthome.html')

def studlogin(req):
    return render(req,'studlogin.html')

def studregister(req):
    return render(req,'studregister.html')

def studinsert(req):
    Name=req.GET.get("Name")
    Email=req.GET.get("Email")
    Pass=req.GET.get("Pass")
    Age=req.GET.get("Age")
    Mob=req.GET.get("Mob")

    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
    mycr=conn.cursor()

    que="insert into student values('{0}','{1}','{2}',{3},{4})".format(Name,Email,Pass,Age,Mob)

    mycr.execute(que)
    conn.commit()
    conn.close()
    return redirect("/stud/studlogin")

def studlogintask(req):
    Email=req.GET.get("Email")
    Pass=req.GET.get("Pass")

    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")

    mycr=conn.cursor()

    mycr.execute("select * from student")
    while True:
        row=mycr.fetchone()
        if row is None:
            break
        elif row[1]==Email and row[2]==Pass:
            return redirect("/stud/home")
    return redirect("/stud/studlogin")                   


def viewstudbooks(req):
	con=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")
	mycr=con.cursor()
	mycr.execute("select Name,Author,Date from books")
	while True:
		books=mycr.fetchall()
		if books is None:
			break
		else:
			return render(req,'viewstudbooks.html',{'books':books})
def aboutus(req):
    return render(req,'aboutus.html') 

def issuebooksrahul(req):
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")

    mycr=conn.cursor()
    mycr.execute("select Name,Link,Author,Date from rahulbooks where Stud_Name like 'R%'")

    while True:
        row=mycr.fetchall()
        if row is None:
            break
        else:
            return render(req,'issuebooks.html',{'row':row})

def issuebooksrohan(req):
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")

    mycr=conn.cursor()
    mycr.execute("select Name,Link,Author,Date from rohanbooks where Stud_Name like 'R%'")

    while True:
        row=mycr.fetchall()
        if row is None:
            break
        else:
            return render(req,'issuebooks.html',{'row':row})

def issuebooksaman(req):
    conn=mysql.connect(host="localhost",user="root",password="Rohan@1234",database="project")

    mycr=conn.cursor()
    mycr.execute("select Name,Link,Author,Date from amanbooks where Stud_Name like 'A%'")

    while True:
        row=mycr.fetchall()
        if row is None:
            break
        else:
            return render(req,'issuebooks.html',{'row':row})                        

def requestbook(req):
    return render(req,'requestbook.html')